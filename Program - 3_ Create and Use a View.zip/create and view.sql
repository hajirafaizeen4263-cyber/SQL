create table student(id int,name varchar(30), age int);


insert into student('id','name','age')
values(101,'harsha',20);
insert into student('id','name','age')
values(121,'priya',19);
insert into student('id','name','age')
values(131,'kashi',22);
insert into student('id','name','age')
values(141,'roshan',21);

create view student_view as select id, name from student;

select * from student_view;
 
