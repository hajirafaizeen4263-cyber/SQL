create table employees(id int,name varchar(40));
 insert into employees('id','name')
 values(101,'aashik');
 insert into employees('id','name')
 values(102,'karthik');
 insert into employees('id','name')
 values(103,'arun');
 
 create table departments(id int,department varchar(50),location varchar(20));
 insert into departments('id','department','location')
 values(101,'sales','japan');
 insert into departments('id','department','location')
 values(102,'manager','uae');
 insert into departments('id','department','location')
 values(103,'packing','usa');
 
 select * from employees join departments where employees.id=departments.id;