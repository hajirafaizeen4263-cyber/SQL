create table student('id' int, 'name'varchar(30),'age' int);

insert into student('id','name','age')
values(101,'harish',12);
insert into student('id','name','age')
values(102,'harsha',15);
insert into student('id','name','age')
values(101,'sara',17);

select * from student;