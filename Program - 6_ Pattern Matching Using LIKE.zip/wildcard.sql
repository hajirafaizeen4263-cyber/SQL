create table collegedb(id int,name varchar(60),course varchar(70));
insert into collegedb('id','name','course')
values(1,'kanishka','bca');
insert into collegedb('id','name','course')
values(2,'rohan','bsc');
insert into collegedb('id','name','course')
values(3,'karthik','btech');
insert into collegedb('id','name','course')
values(4,'ram','bcom');
insert into collegedb('id','name','course')
values(5,'rahul','bba');

select * from collegedb where course like 'b_a';