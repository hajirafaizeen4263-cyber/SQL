create table student('id','name','age');

insert into student('id','name','age')
values(101,'mehta',13);
values(102,'hanna',20);
values(103,'riya',17);
values(104,'aparna',10);

select * from student where age not between 12 and 17;
