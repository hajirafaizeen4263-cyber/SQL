create table customer('id' int, 'name' varchar(50),age int);

insert into customer('id', 'name', 'age')
values(132,'mehat', 32);

insert into customer('id', 'name', 'age')
values(231, 'lakshman', 40);

insert into customer('id', 'name', 'age')
values(421, 'ran', 45);