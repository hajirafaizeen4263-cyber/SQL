create table students(student_id int,name varchar(50),course varchar(30));

insert into students('student_id','name','course')
values(101,'arthika','bca');
values(102,'bavya','btech');
values(103,'catherine','bsc');

select * from students;