create table student('id' int primary key, 'name' varchar(60), 'subject' varchar(90) default 'english');

insert into student(id,name)
values(401,'nisha');
insert into student(id,name)
values(402,'irish');
insert into student(id,name)
values(403,'rinos');
insert into student(id,name)
values(404,'fidha');
insert into student(id,name)
values(401,'appu');