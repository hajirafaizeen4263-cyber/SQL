create table customer('id' int, 'name' varchar(30),'age' int);
insert into customer('id', 'name', 'age')
values(301,'nitha',36);
values(302,'hashir',21);
values(303,'alan',30);
values(304,'abbas',23);
values(305,'nifa',42);