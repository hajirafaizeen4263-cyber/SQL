create table student(id int,name varchar(30), age int);
create table course(id int, course_name varchar(40),fees int);

insert into student('id','name','age')
values(101,'harsha',20);
insert into student('id','name','age')
values(121,'priya',19);
insert into student('id','name','age')
values(131,'kashi',22);
insert into student('id','name','age')
values(141,'roshan',21);
insert into course('id','course_name','fees')
values(101,'bca',1500);
insert into course('id','course_name','fees')
values(121,'bba',1650);
insert into course('id','course_name','fees')
values(131,'bcom',1200);
insert into course('id','course_name','fees')
values(141,'btech',1700);

select * from student left outer join course on student.id = course.id;